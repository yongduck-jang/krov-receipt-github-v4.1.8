import React, { useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Image,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as ImageManipulator from 'expo-image-manipulator';
import * as ImagePicker from 'expo-image-picker';
import { StatusBar } from 'expo-status-bar';

const APP_BUILD = 'mobile-v4.1.8-ocr-web-sync';
const API_BASE = process.env.EXPO_PUBLIC_API_BASE_URL || 'https://k-rov.com/api';

export default function App() {
  const [token, setToken] = useState('');
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState('admin@k-rov.com');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState('');
  const [image, setImage] = useState(null);
  const [rawText, setRawText] = useState('');
  const [receipt, setReceipt] = useState(null);
  const [receipts, setReceipts] = useState([]);

  const loggedIn = Boolean(token);
  const totalText = useMemo(() => (receipt ? won(receipt.total) : '0원'), [receipt]);

  useEffect(() => {
    (async () => {
      const savedToken = await AsyncStorage.getItem('krovToken');
      const savedUser = await AsyncStorage.getItem('krovUser');
      if (savedToken) setToken(savedToken);
      if (savedUser) {
        try { setUser(JSON.parse(savedUser)); } catch (_) {}
      }
    })();
  }, []);

  useEffect(() => {
    if (token) loadReceipts();
  }, [token]);

  async function api(path, options = {}) {
    const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
    if (token) {
      headers.Authorization = `Bearer ${token}`;
      headers['X-KROV-AUTHORIZATION'] = `Bearer ${token}`;
    }
    const response = await fetch(`${API_BASE}${path}`, { ...options, headers });
    const contentType = response.headers.get('content-type') || '';
    const text = await response.text();
    if (/^\s*</.test(text) || /text\/html/i.test(contentType)) {
      throw new Error(`API가 JSON이 아니라 HTML을 반환했습니다. (${path}, HTTP ${response.status})`);
    }
    let data = {};
    try { data = text ? JSON.parse(text) : {}; } catch { data = { ok: false, message: text || `HTTP ${response.status}` }; }
    if (response.status === 401 && path !== '/auth/login.php') {
      await logout(false);
      throw new Error(data.message || '로그인이 필요합니다.');
    }
    if (!response.ok || data.ok === false) throw new Error(data.message || `HTTP ${response.status}`);
    return data;
  }

  async function login() {
    try {
      setLoading(true);
      setStatus('로그인 중...');
      const data = await api('/auth/login.php', {
        method: 'POST',
        body: JSON.stringify({ email: email.trim(), password }),
      });
      if (!data.token) throw new Error('로그인 응답에 token이 없습니다.');
      setToken(data.token);
      setUser(data.user || null);
      await AsyncStorage.setItem('krovToken', data.token);
      await AsyncStorage.setItem('krovUser', JSON.stringify(data.user || null));
      setStatus('로그인 완료');
    } catch (error) {
      Alert.alert('로그인 실패', error.message);
      setStatus(error.message);
    } finally {
      setLoading(false);
    }
  }

  async function logout(showMessage = true) {
    setToken('');
    setUser(null);
    setReceipt(null);
    setRawText('');
    setImage(null);
    await AsyncStorage.removeItem('krovToken');
    await AsyncStorage.removeItem('krovUser');
    if (showMessage) setStatus('로그아웃되었습니다.');
  }

  async function pickImage(mode) {
    try {
      const permission = mode === 'camera'
        ? await ImagePicker.requestCameraPermissionsAsync()
        : await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) {
        Alert.alert('권한 필요', '이미지 선택/촬영 권한이 필요합니다.');
        return;
      }
      const result = mode === 'camera'
        ? await ImagePicker.launchCameraAsync({ quality: 0.9, allowsEditing: false })
        : await ImagePicker.launchImageLibraryAsync({ quality: 0.9, allowsEditing: false, mediaTypes: ImagePicker.MediaTypeOptions.Images });
      if (result.canceled || !result.assets?.[0]?.uri) return;
      setStatus('이미지 압축 중...');
      const prepared = await prepareImage(result.assets[0].uri);
      setImage(prepared);
      setReceipt(null);
      setRawText('');
      setStatus(`이미지 준비 완료: ${prepared.width}x${prepared.height}, 약 ${Math.round(prepared.base64.length / 1024)}KB`);
    } catch (error) {
      Alert.alert('이미지 처리 실패', error.message);
      setStatus(error.message);
    }
  }

  async function prepareImage(uri) {
    let quality = 0.68;
    let resizeWidth = 960;
    let manipulated = null;
    for (let i = 0; i < 5; i += 1) {
      manipulated = await ImageManipulator.manipulateAsync(
        uri,
        [{ resize: { width: resizeWidth } }],
        { compress: quality, format: ImageManipulator.SaveFormat.JPEG, base64: true }
      );
      if ((manipulated.base64 || '').length <= 850000 || quality <= 0.38) break;
      quality = Math.max(0.38, quality - 0.08);
      resizeWidth = Math.max(720, resizeWidth - 80);
    }
    return {
      uri: manipulated.uri,
      base64: manipulated.base64 || '',
      width: manipulated.width,
      height: manipulated.height,
      quality,
      format: 'jpg',
      mimeType: 'image/jpeg',
      name: 'receipt-mobile.jpg',
    };
  }

  async function runOcr() {
    if (!image?.base64) {
      Alert.alert('이미지 필요', '먼저 영수증 이미지를 선택하거나 촬영하세요.');
      return;
    }
    try {
      setLoading(true);
      setStatus('OCR 분석 중...');
      const data = await api('/ocr/receipt.php', {
        method: 'POST',
        body: JSON.stringify({
          base64: image.base64,
          format: image.format,
          fileName: image.name,
          mimeType: image.mimeType,
          clientBuild: APP_BUILD,
          imageMeta: {
            width: image.width,
            height: image.height,
            compressedKb: Math.round(image.base64.length / 1024),
          },
        }),
      });
      const text = data.rawText || '';
      const parsed = parseReceipt(text, user);
      setRawText(text);
      setReceipt(parsed);
      setStatus(`OCR 완료: ${text.length.toLocaleString('ko-KR')}자 / ${parsed.quantitySummary}`);
    } catch (error) {
      Alert.alert('OCR 실패', error.message);
      setStatus(error.message);
    } finally {
      setLoading(false);
    }
  }

  async function saveReceipt() {
    if (!receipt) return;
    try {
      setLoading(true);
      setStatus('영수증 저장 중...');
      const data = await api('/receipts/create.php', { method: 'POST', body: JSON.stringify(receipt) });
      setReceipt(data.receipt || receipt);
      setStatus('저장 완료');
      await loadReceipts();
    } catch (error) {
      Alert.alert('저장 실패', error.message);
      setStatus(error.message);
    } finally {
      setLoading(false);
    }
  }

  async function loadReceipts() {
    try {
      const data = await api('/receipts/list.php');
      setReceipts(data.receipts || []);
    } catch (error) {
      setStatus(`목록 조회 실패: ${error.message}`);
    }
  }

  function updateField(key, value) {
    setReceipt((prev) => {
      if (!prev) return prev;
      const next = { ...prev, [key]: ['amount', 'supplyAmount', 'vat', 'total'].includes(key) ? money(value) : value };
      if (['amount', 'total', 'vat'].includes(key)) {
        next.supplyAmount = Math.max(money(next.total) - money(next.vat), 0);
        next.items = distributeItemVat(next.items || [], money(next.total), money(next.vat), next.category, next.expenseStatus);
      }
      return recalcExpense(next);
    });
  }

  if (!loggedIn) {
    return (
      <SafeAreaView style={styles.safe}>
        <StatusBar style="dark" />
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.flex}>
          <ScrollView contentContainerStyle={styles.container}>
            <Text style={styles.logo}>KR</Text>
            <Text style={styles.title}>K-ROV 영수증 비용관리</Text>
            <Text style={styles.subtitle}>모바일 OCR 등록 앱</Text>
            <Text style={styles.label}>이메일</Text>
            <TextInput value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" style={styles.input} />
            <Text style={styles.label}>비밀번호</Text>
            <TextInput value={password} onChangeText={setPassword} secureTextEntry style={styles.input} />
            <Button title="로그인" onPress={login} disabled={loading} primary />
            <Text style={styles.status}>{status || `API: ${API_BASE}`}</Text>
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.flex}>
        <ScrollView contentContainerStyle={styles.container}>
          <View style={styles.headerRow}>
            <View>
              <Text style={styles.title}>영수증 등록</Text>
              <Text style={styles.subtitle}>{user?.name || user?.email || '로그인 사용자'} · {APP_BUILD}</Text>
            </View>
            <Pressable onPress={() => logout()} style={styles.logout}><Text style={styles.logoutText}>로그아웃</Text></Pressable>
          </View>

          <View style={styles.card}>
            <Text style={styles.cardTitle}>1. 이미지 선택</Text>
            <View style={styles.row}>
              <Button title="촬영" onPress={() => pickImage('camera')} />
              <Button title="앨범" onPress={() => pickImage('library')} />
            </View>
            {image?.uri ? <Image source={{ uri: image.uri }} style={styles.preview} /> : <Text style={styles.empty}>영수증 이미지를 선택하세요.</Text>}
            <Button title="OCR 분석 시작" onPress={runOcr} disabled={!image || loading} primary />
          </View>

          {loading ? <ActivityIndicator size="large" color="#2563eb" style={styles.spinner} /> : null}
          <Text style={styles.status}>{status}</Text>

          {receipt ? (
            <View style={styles.card}>
              <Text style={styles.cardTitle}>2. 분석 결과</Text>
              <Text style={styles.totalText}>{totalText}</Text>
              <Field label="날짜" value={receipt.date} onChangeText={(v) => updateField('date', v)} />
              <Field label="시간" value={receipt.time} onChangeText={(v) => updateField('time', v)} />
              <Field label="분류" value={receipt.category} onChangeText={(v) => updateField('category', v)} />
              <Field label="판매처" value={receipt.storeName} onChangeText={(v) => updateField('storeName', v)} />
              <Field label="주소" value={receipt.address} onChangeText={(v) => updateField('address', v)} />
              <View style={styles.row}>
                <Field label="Total" value={String(receipt.total || 0)} onChangeText={(v) => updateField('total', v)} half />
                <Field label="VAT" value={String(receipt.vat || 0)} onChangeText={(v) => updateField('vat', v)} half />
              </View>
              <Field label="비용상태" value={receipt.expenseStatus} onChangeText={(v) => updateField('expenseStatus', v)} />
              <Field label="메모" value={receipt.memo} onChangeText={(v) => updateField('memo', v)} multiline />
              <Text style={styles.sectionTitle}>품목 {receipt.items?.length || 0}개</Text>
              {(receipt.items || []).map((item, idx) => (
                <View key={`${item.id}-${idx}`} style={styles.itemBox}>
                  <Text style={styles.itemName}>{idx + 1}. {item.name}</Text>
                  <Text style={styles.itemMeta}>수량 {item.quantity} · 단가 {won(item.unitPrice || 0)} · 금액 {won(item.amount)}</Text>
                </View>
              ))}
              <Button title="영수증 저장" onPress={saveReceipt} disabled={loading} primary />
            </View>
          ) : null}

          <View style={styles.card}>
            <View style={styles.headerRow}>
              <Text style={styles.cardTitle}>최근 영수증</Text>
              <Pressable onPress={loadReceipts}><Text style={styles.link}>새로고침</Text></Pressable>
            </View>
            {receipts.length ? receipts.slice(0, 12).map((r) => (
              <View key={String(r.serverId || r.id)} style={styles.receiptRow}>
                <Text style={styles.itemName}>{r.date} · {r.category}</Text>
                <Text style={styles.itemMeta}>{r.storeName || r.sellerCompany || '-'} · {won(r.total)} · {r.expenseStatus}</Text>
              </View>
            )) : <Text style={styles.empty}>등록된 영수증이 없습니다.</Text>}
          </View>

          {rawText ? (
            <View style={styles.card}>
              <Text style={styles.cardTitle}>OCR 원문</Text>
              <Text style={styles.rawText}>{rawText}</Text>
            </View>
          ) : null}
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

function Button({ title, onPress, disabled, primary }) {
  return (
    <Pressable onPress={onPress} disabled={disabled} style={[styles.button, primary && styles.buttonPrimary, disabled && styles.buttonDisabled]}>
      <Text style={[styles.buttonText, primary && styles.buttonTextPrimary]}>{title}</Text>
    </Pressable>
  );
}

function Field({ label, value, onChangeText, multiline, half }) {
  return (
    <View style={[styles.field, half && styles.half]}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        value={value == null ? '' : String(value)}
        onChangeText={onChangeText}
        style={[styles.input, multiline && styles.textarea]}
        multiline={multiline}
      />
    </View>
  );
}

function parseReceipt(rawText, user) {
  const text = normalizeOcrText(rawText || '');
  const now = new Date();
  const dateMatch = text.match(/(20\d{2})[.\-\/년\s]+(\d{1,2})[.\-\/월\s]+(\d{1,2})/);
  const timeMatch = text.match(/(\d{1,2}:\d{2})(?::\d{2})?/);
  const date = dateMatch ? `${dateMatch[1]}-${pad(dateMatch[2])}-${pad(dateMatch[3])}` : todayDate();
  const time = timeMatch ? timeMatch[1] : `${pad(now.getHours())}:${pad(now.getMinutes())}`;
  const category = detectCategory(text);
  const status = classify(category);
  const seller = detectSeller(text, category);
  let items = extractReceiptItems(text, category, status);
  const itemTotal = money(items.reduce((sum, item) => sum + money(item.amount), 0));
  let total = money(detectTotal(text, itemTotal) || itemTotal);
  if (itemTotal > 0 && total > itemTotal * 3 && total - itemTotal > 50000) total = itemTotal;
  const vat = money(detectVat(text, total));
  if (!items.length && total > 0) items = [makeReceiptItem(category || '영수증', 1, null, total, category, status, 1)];
  items = distributeItemVat(items, total, vat, category, status);
  const receipt = {
    id: `mobile-${Date.now()}`,
    date,
    time,
    user: user?.name || '',
    category,
    items,
    amount: total,
    supplyAmount: Math.max(total - vat, 0),
    vat,
    total,
    taxFreeAmount: detectTaxFreeAmount(text),
    paymentMethod: /현금|cash/i.test(text) ? '현금' : (/카드|신용|체크|삼성카드|BC|비씨/i.test(text) ? '신용카드' : '미확인'),
    cardCompany: detectCard(text),
    cardMasked: detectCardMasked(text),
    quantitySummary: items.length ? `${items.length}개 품목` : '1건',
    sellerCompany: seller,
    storeName: seller,
    address: detectAddress(text),
    businessNo: detectBusinessNo(text),
    phone: detectPhone(text),
    expenseStatus: status,
    workflowStatus: 'submitted',
    memo: reasonFor(category, status),
    rawText: text,
    sourceImageUri: '',
  };
  return recalcExpense(receipt);
}

function recalcExpense(receipt) {
  const total = money(receipt.total || receipt.amount);
  if (receipt.expenseStatus === '가능') {
    return { ...receipt, expensePossibleAmount: total, expensePendingAmount: 0, expenseNotAllowedAmount: 0 };
  }
  if (receipt.expenseStatus === '불가') {
    return { ...receipt, expensePossibleAmount: 0, expensePendingAmount: 0, expenseNotAllowedAmount: total };
  }
  if (receipt.expenseStatus === '부분가능') {
    const possible = money(receipt.expensePossibleAmount || Math.round(total * 0.35));
    return { ...receipt, expensePossibleAmount: possible, expensePendingAmount: 0, expenseNotAllowedAmount: Math.max(total - possible, 0) };
  }
  return { ...receipt, expensePossibleAmount: 0, expensePendingAmount: total, expenseNotAllowedAmount: 0 };
}

function normalizeOcrText(text) {
  return String(text || '').replace(/\u00a0/g, ' ').replace(/[，]/g, ',').replace(/[₩￦]/g, '원').replace(/[‐‑‒–—―]/g, '-');
}
function receiptLines(text) {
  return normalizeOcrText(text).split(/\r?\n/).map((line) => line.replace(/\s+/g, ' ').trim()).filter(Boolean);
}
function pad(v) { return String(v).padStart(2, '0'); }
function todayDate() { return new Date().toISOString().slice(0, 10); }
function money(value) { const n = Number(String(value ?? '').replace(/[^0-9.]/g, '')); return Number.isFinite(n) && n > 0 ? Math.round(n) : 0; }
function qty(value) { const n = Number(value); return Number.isFinite(n) && n > 0 ? Math.round(n * 1000) / 1000 : 1; }
function won(n) { return `${Number(n || 0).toLocaleString('ko-KR')}원`; }

function detectCategory(text) {
  if (/휘발유|경유|주유|셀프주유소|주유소|유종|리터|\bLPG\b/i.test(text)) return '주유비';
  if (/통행료|하이패스|도로공사|톨게이트/i.test(text)) return '통행료';
  if (/주차|parking|공영주차/i.test(text)) return '주차요금';
  if (/식대|회식|식당|카페|커피|스타벅스|맥도날드|음식|분식|고기|치킨/i.test(text)) return '식대';
  if (/약국|의약품|구급|파스|연고|밴드|거즈|소독|멸균|드레싱|포비돈|타이레놀|판피린|비겐|크림|멘소래담|생력/i.test(text)) return '약국/구급품';
  if (/문구|사무|복사용지|토너|잉크|파일|테이프/i.test(text)) return '사무용품';
  return '기타';
}
function classify(category) {
  if (['주유비', '통행료', '주차요금', '사무용품'].includes(category)) return '가능';
  if (category === '약국/구급품') return '부분가능';
  return '확인필요';
}
function reasonFor(category, status) {
  if (status === '가능') return `${category} 항목은 업무 관련성 확인 시 비용 처리 가능`;
  if (status === '부분가능') return '현장 구급/비상용 품목은 가능, 개인 복용/개인용품은 제외 검토 필요';
  return '거래처, 참석자, 업무 목적 확인 필요';
}
function isIdentifierLine(line) {
  return /승인\s*번호|카드\s*번호|유효\s*기간|사업자|전화|TEL|영수증\s*NO|영수증번호|가맹점|매입사|카드명|주소|일자|날짜|포스|POS|TID|NOZZLE|거래번호|주유기번호/i.test(line);
}
function extractMoneyValues(line, loose = false) {
  const source = String(line || '');
  const values = [];
  const commaPattern = /\d{1,3}(?:,\d{3})+(?:\s*원)?/g;
  for (const match of source.match(commaPattern) || []) values.push(money(match));
  const bare = source.replace(commaPattern, ' ');
  if (loose || /원|금액|합계|총액|결제|청구|받는|받은|카드|소계|VAT|부가세|공급가액|판매금액|amount|total/i.test(source)) {
    for (const match of bare.match(/\b\d{3,9}\b/g) || []) values.push(money(match));
  }
  return [...new Set(values)].filter((n) => n > 0 && n < 1000000000);
}
function moneyNearLine(lines, i) {
  const parts = [lines[i]];
  for (let j = i + 1; j < Math.min(lines.length, i + 5); j += 1) {
    if (isIdentifierLine(lines[j])) break;
    parts.push(lines[j]);
    if (extractMoneyValues(parts.join(' '), true).length) break;
  }
  return extractMoneyValues(parts.join(' '), true);
}
function detectTotal(text, hintTotal = 0) {
  const lines = receiptLines(text);
  const totalKeywords = /청구\s*금액|받는\s*금액|받은\s*금액|결제\s*금액|합\s*계|총\s*액|총\s*금액|신용\s*카드|카드\s*결제|소\s*계|판매\s*금액|total|amount/i;
  const notTotal = /부가세|부\s*가\s*세|공급\s*가|면세|과세\s*물품/i;
  for (let i = lines.length - 1; i >= 0; i -= 1) {
    if (!totalKeywords.test(lines[i]) || notTotal.test(lines[i]) || isIdentifierLine(lines[i])) continue;
    const values = moneyNearLine(lines, i);
    if (values.length) return values[values.length - 1];
  }
  if (hintTotal > 0) return hintTotal;
  const fallback = [];
  for (const line of lines) if (!isIdentifierLine(line) && !notTotal.test(line)) fallback.push(...extractMoneyValues(line, false));
  return fallback.length ? Math.max(...fallback) : 0;
}
function detectVat(text, total) {
  const lines = receiptLines(text);
  for (let i = 0; i < lines.length; i += 1) {
    if (!/(^|\s)(VAT|부\s*가\s*세|부가세|세액)(\s|:|：|$)/i.test(lines[i])) continue;
    const values = extractMoneyValues(lines.slice(i, i + 10).join(' '), true).filter((n) => n > 0 && (!total || n <= Math.round(total * 0.2)));
    if (values.length) return values[values.length - 1];
  }
  return total ? Math.round(total / 11) : 0;
}
function detectTaxFreeAmount(text) {
  const lines = receiptLines(text);
  const idx = lines.findIndex((l) => /면세\s*물품|면세\s*금액|비과세/i.test(l));
  if (idx < 0) return 0;
  const values = extractMoneyValues(lines.slice(idx, idx + 8).join(' '), true);
  return values.length ? values[values.length - 1] : 0;
}
function extractReceiptItems(text, defaultCategory, defaultStatus) {
  const lines = receiptLines(text);
  const pharmacyItems = extractPharmacyColumnItems(lines, defaultCategory, defaultStatus, text);
  if (pharmacyItems.length >= 3) return pharmacyItems;
  let start = lines.findIndex((line) => /품명|품목|상품명|제품명|내역|단가.*수량.*금액/i.test(line));
  if (start < 0) start = -1;
  const section = [];
  for (let i = start + 1; i < lines.length; i += 1) {
    const line = lines[i].replace(/^[-=*\s]+|[-=*\s]+$/g, '').trim();
    if (!line || isItemHeaderLine(line)) continue;
    if (isItemFooterLine(line)) break;
    section.push(line);
  }
  const items = [];
  for (let i = 0; i < section.length; i += 1) {
    const line = section[i];
    const inline = parseInlineItem(line, defaultCategory, defaultStatus, items.length + 1);
    if (inline) { items.push(inline); continue; }
    if (!looksLikeItemName(line)) continue;
    const nameParts = [line];
    let cursor = i + 1;
    while (cursor < section.length && isItemNameContinuation(section[cursor]) && numericRunLength(section, cursor + 1) > 0) {
      nameParts.push(section[cursor]);
      cursor += 1;
    }
    const tokens = [];
    while (cursor < section.length && isNumericOnlyLine(section[cursor]) && tokens.length < 6) {
      tokens.push(...numericTokens(section[cursor]));
      cursor += 1;
    }
    const item = makeItemFromTokens(nameParts.join(' '), tokens, defaultCategory, defaultStatus, items.length + 1);
    if (item) { items.push(item); i = cursor - 1; }
  }
  return items.filter((item) => item.amount > 0);
}
function extractPharmacyColumnItems(lines, defaultCategory, defaultStatus, fullText) {
  if (defaultCategory !== '약국/구급품' && !/약국|파스|연고|밴드|거즈|타이레놀|판피린/i.test(fullText || '')) return [];
  const start = lines.findIndex((line) => /품명|제품명|상품명|단가|수량|금액/i.test(line));
  const end = lines.findIndex((line, idx) => idx > start && /소\s*계|청구\s*금액|받은\s*금액|신용\s*카드|카드\s*번호|결제\s*금액/i.test(line));
  if (start < 0 || end <= start) return [];
  const section = lines.slice(start + 1, end).map((line) => line.replace(/^[-=*\s]+|[-=*\s]+$/g, '').trim()).filter(Boolean);
  const names = orderPharmacyNames(collectPharmacyNames(section));
  const total = money(detectTotal(fullText, 0));
  const amounts = findAmountRun(extractColumnAmounts(section, total), total, names.length);
  if (names.length < 3 || amounts.length < 3) return [];
  return names.slice(0, Math.min(names.length, amounts.length)).map((name, idx) => {
    const amount = money(amounts[idx]);
    const detail = pharmacyQuantityAndUnitPrice(name, amount);
    return makeReceiptItem(name, detail.quantity, detail.unitPrice, amount, defaultCategory, defaultStatus, idx + 1);
  });
}
function collectPharmacyNames(section) {
  const names = [];
  let current = '';
  for (const rawLine of section) {
    const line = rawLine.replace(/\s+/g, ' ').trim();
    if (!line || isNumericOnlyLine(line) || isItemHeaderLine(line) || isItemFooterLine(line)) continue;
    if (/^[,:：]+$/.test(line) || /^(단가|수량|금액|품명|제품명)$/i.test(line)) continue;
    if (isPharmacyContinuation(line)) { if (current) current = `${current} ${line}`.trim(); continue; }
    if (!/[가-힣A-Za-z]/.test(line)) continue;
    if (current) names.push(current);
    current = line;
  }
  if (current) names.push(current);
  return names.map((name) => name.replace(/\s+/g, ' ').trim()).filter(Boolean);
}
function isPharmacyContinuation(line) { return /^\(?[^)]*변방\)?$/i.test(line) || /^(혼합|대체변방)$/i.test(line) || /^\d+(?:\.\d+)?\s*(?:P|T|g|mg|ml|mL|L|병|매|개입|ea|EA|포|정|봉|팩)$/i.test(line); }
function extractColumnAmounts(section, total) { const values = []; for (const line of section) { if (!(isNumericOnlyLine(line) || /\d{1,3}(?:,\d{3})+/.test(line))) continue; for (const n of numericTokens(line)) if (n > 100 && (!total || n < total)) values.push(money(n)); } return values; }
function findAmountRun(values, total, targetCount) { if (!values.length) return []; if (!total) return values.slice(-targetCount); for (let start = 0; start < values.length; start += 1) { let sum = 0; const run = []; for (let end = start; end < values.length; end += 1) { sum += values[end]; run.push(values[end]); if (sum === total && run.length >= Math.min(3, targetCount || run.length)) return run; if (sum > total) break; } } return values.slice(-targetCount); }
function orderPharmacyNames(names) { const preferred = ['자하생력', '판피린큐맥', '판피린큐액', '제일롱파프', '리스테린', '멸균거즈', '경방갈근', '용표우황', '비겐크림', '타이레놀', '가그린', '후시딘', '밴드닥터', '포비돈', '로푸록스']; const ordered = []; const used = new Set(); for (const key of preferred) { const idx = names.findIndex((name, i) => !used.has(i) && name.includes(key)); if (idx >= 0) { ordered.push(names[idx]); used.add(idx); } } for (let i = 0; i < names.length; i += 1) if (!used.has(i)) ordered.push(names[i]); return ordered; }
function pharmacyQuantityAndUnitPrice(name, amount) { if (/판피린큐액/i.test(name) && amount === 27500) return { quantity: 11, unitPrice: 2500 }; if (/용표우황/i.test(name) && amount === 20000) return { quantity: 4, unitPrice: 5000 }; return { quantity: 1, unitPrice: amount }; }
function isItemHeaderLine(line) { return /^(품명|품목|상품명|제품명|내역|단가|수량|금액)$|품명\s+단가|단가\s+수량/i.test(line); }
function isItemFooterLine(line) { return /소\s*계|합\s*계|청구\s*금액|받는\s*금액|받은\s*금액|거스름돈|부가세|공급\s*가액|신용\s*카드|카드\s*번호|유효\s*기간|가맹점|매입사|결제\s*금액|승인\s*번호|면세\s*물품|과세\s*물품/i.test(line); }
function isNumericOnlyLine(line) { return /^[\d,.\s원]+$/.test(String(line || '').trim()); }
function numericTokens(line) { return (String(line || '').match(/\d{1,3}(?:,\d{3})+|\b\d+(?:\.\d+)?\b/g) || []).map((value) => Number(String(value).replace(/,/g, ''))).filter((n) => Number.isFinite(n) && n >= 0); }
function numericRunLength(lines, start) { let count = 0; for (let i = start; i < lines.length && isNumericOnlyLine(lines[i]); i += 1) count += 1; return count; }
function looksLikeItemName(line) { const s = String(line || '').trim(); if (!s || isIdentifierLine(s) || isItemFooterLine(s) || isItemHeaderLine(s) || isNumericOnlyLine(s)) return false; if (/^(주소|전화|성명|일자|포스|사업자|대표|카드|가맹점|매입사)\s*[:：]?/i.test(s)) return false; return /[가-힣A-Za-z]/.test(s); }
function isItemNameContinuation(line) { return /^[\d.\s]+(?:병|개|매|ml|mL|g|kg|L|P|포|입|ea|EA|T|정|봉|팩)\b/i.test(line); }
function parseInlineItem(line, defaultCategory, defaultStatus, index) { const s = String(line || '').replace(/\s+/g, ' ').trim(); if (!looksLikeItemName(s)) return null; let m = s.match(/^(.+?)\s+(\d{1,3}(?:,\d{3})+|\d{3,9})\s+(\d+(?:\.\d+)?)\s+(\d{1,3}(?:,\d{3})+|\d{3,9})(?:\s*원)?$/); if (m) return makeReceiptItem(m[1], Number(m[3]) || 1, money(m[2]), money(m[4]), defaultCategory, defaultStatus, index); m = s.match(/^(.+?)\s+(\d{1,3}(?:,\d{3})+)(?:\s*원)?$/); if (m) return makeReceiptItem(m[1], 1, null, money(m[2]), defaultCategory, defaultStatus, index); return null; }
function makeItemFromTokens(name, tokens, defaultCategory, defaultStatus, index) { const values = tokens.filter((n) => Number.isFinite(n) && n > 0); if (!values.length) return null; let quantity = 1; let unitPrice = null; let amount = money(values[values.length - 1]); if (values.length >= 3) { const first = values[0]; const second = values[1]; if (first > 0 && first < 1000 && second >= 100 && Math.abs((first * second) - amount) <= Math.max(100, amount * 0.08)) { quantity = first; unitPrice = second; } else if (second > 0 && second < 1000 && first >= 100) { unitPrice = first; quantity = second; } else { unitPrice = first >= 100 ? first : null; quantity = unitPrice ? qty(amount / unitPrice) : 1; } } else if (values.length === 2) { unitPrice = values[0] >= 100 ? values[0] : null; amount = money(values[1]); } return makeReceiptItem(name, quantity, unitPrice, amount, defaultCategory, defaultStatus, index); }
function makeReceiptItem(name, quantity, unitPrice, amount, defaultCategory, defaultStatus, index) { const cleanName = String(name || '미분류 품목').replace(/^\*+/, '').replace(/\s+/g, ' ').trim() || '미분류 품목'; const detected = detectCategory(cleanName); const category = detected === '기타' ? defaultCategory : detected; const status = defaultStatus || classify(category); return { id: `item-${index}`, name: cleanName.slice(0, 180), category, quantity: qty(quantity), unit: '', unitPrice: money(unitPrice) || null, amount: money(amount), vat: 0, expenseStatus: status, reason: reasonFor(category, status) }; }
function distributeItemVat(items, total, vat, defaultCategory, defaultStatus) { if (!items.length) return items; let assignedVat = 0; return items.map((item, idx) => { const category = item.category || defaultCategory; const status = item.expenseStatus || defaultStatus; const itemAmount = money(item.amount); const itemVat = idx === items.length - 1 ? money(vat - assignedVat) : (total && vat ? money(vat * itemAmount / total) : money(itemAmount / 11)); assignedVat += itemVat; return { ...item, id: item.id || `item-${idx + 1}`, category, expenseStatus: status, vat: itemVat, reason: item.reason || reasonFor(category, status) }; }); }
function detectSeller(text, category) { const lines = receiptLines(text).slice(0, 16); const blocked = /영수증|사업자|주소|전화|성명|일자|포스|카드|가맹점|매입사|승인|NO\s*[:：]?|대표|TID|NOZZLE/i; const likely = lines.find((line) => !blocked.test(line) && /(약국|주유소|식당|카페|마트|상사|병원|문구|커피|공영|도로공사|하이패스|parking|store|pharmacy|에너지)/i.test(line)); const first = likely || lines.find((line) => !blocked.test(line) && /[가-힣A-Za-z]/.test(line)); return cleanupSeller(first || category); }
function cleanupSeller(value) { return String(value || '').replace(/^(서울|부산|대구|인천|광주|대전|울산|세종|경기|강원|충북|충남|전북|전남|경북|경남|제주)\s+/, '').replace(/\s+/g, ' ').trim(); }
function detectAddress(text) { const line = receiptLines(text).find((l) => /(서울|부산|대구|인천|광주|대전|울산|세종|경기|강원|충북|충남|전북|전남|경북|경남|제주).*(시|군|구).*(로|길|대로)\s*\d*/.test(l)); return line ? line.replace(/^주소\s*[:：]?\s*/, '').trim() : ''; }
function detectBusinessNo(text) { const lines = receiptLines(text); const idx = lines.findIndex((line) => /사업자\s*번호/i.test(line)); const source = idx >= 0 ? [lines[idx], lines[idx + 1] || '', lines[idx + 2] || ''].join(' ') : text; const m = source.match(/(\d{3})-?(\d{2})-?(\d{5})/); return m ? `${m[1]}-${m[2]}-${m[3]}` : ''; }
function detectPhone(text) { return text.match(/0\d{1,2}-\d{3,4}-\d{4}/)?.[0] || ''; }
function detectCard(text) { const brandPattern = /(삼성|현대|국민|신한|우리|롯데|하나|농협|BC|비씨)[\s-]*(카드|카드사)?/i; const lines = receiptLines(text); for (let i = lines.length - 1; i >= 0; i -= 1) { const windowText = [lines[i - 1] || '', lines[i], lines[i + 1] || ''].join(' '); if (!/카드|매입|승인|사\s*[:：]?/i.test(windowText)) continue; const m = windowText.match(brandPattern); if (m) return `${m[1]}카드`.replace(/^BC카드$/i, 'BC카드').replace(/^비씨카드$/, '비씨카드'); } return ''; }
function detectCardMasked(text) { return text.match(/\d{4}[-\s]\d{4}[-\s][*Xx]{2,4}[-\s][*Xx]{2,4}/)?.[0] || ''; }

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#eef4ff' },
  flex: { flex: 1 },
  container: { padding: 18, paddingBottom: 44 },
  logo: { alignSelf: 'flex-start', backgroundColor: '#2563eb', color: '#fff', fontWeight: '900', fontSize: 26, paddingHorizontal: 14, paddingVertical: 10, borderRadius: 18, marginBottom: 18 },
  title: { fontSize: 28, fontWeight: '900', color: '#0f2347', letterSpacing: -0.5 },
  subtitle: { color: '#59708f', marginTop: 6, marginBottom: 16 },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 12 },
  card: { backgroundColor: '#fff', borderRadius: 24, padding: 18, marginTop: 16, shadowColor: '#1d3557', shadowOpacity: 0.08, shadowRadius: 18, elevation: 3 },
  cardTitle: { fontSize: 18, fontWeight: '900', color: '#0f2347', marginBottom: 12 },
  sectionTitle: { fontSize: 16, fontWeight: '900', color: '#0f2347', marginTop: 14, marginBottom: 8 },
  row: { flexDirection: 'row', gap: 10, alignItems: 'center' },
  input: { backgroundColor: '#f8fbff', borderWidth: 1, borderColor: '#d8e2f0', borderRadius: 14, paddingHorizontal: 14, paddingVertical: 12, fontSize: 16, color: '#0f2347', marginTop: 6, marginBottom: 12 },
  textarea: { minHeight: 86, textAlignVertical: 'top' },
  field: { flex: 1 },
  half: { flexBasis: '48%' },
  label: { color: '#314766', fontWeight: '800', marginTop: 6 },
  button: { backgroundColor: '#e9f0fb', borderRadius: 16, paddingVertical: 14, paddingHorizontal: 18, alignItems: 'center', justifyContent: 'center', flex: 1, marginTop: 8 },
  buttonPrimary: { backgroundColor: '#2563eb' },
  buttonDisabled: { opacity: 0.45 },
  buttonText: { color: '#153156', fontWeight: '900', fontSize: 16 },
  buttonTextPrimary: { color: '#fff' },
  logout: { paddingHorizontal: 12, paddingVertical: 9, backgroundColor: '#fff', borderRadius: 999 },
  logoutText: { color: '#d11f3d', fontWeight: '900' },
  preview: { width: '100%', height: 260, borderRadius: 18, marginVertical: 14, backgroundColor: '#d8e2f0' },
  empty: { color: '#7b8ca8', paddingVertical: 18 },
  status: { color: '#536784', marginTop: 12, lineHeight: 20 },
  spinner: { marginTop: 14 },
  totalText: { fontSize: 30, fontWeight: '900', color: '#2563eb', marginBottom: 12 },
  itemBox: { backgroundColor: '#f4f8ff', borderRadius: 16, padding: 12, marginBottom: 8 },
  itemName: { color: '#0f2347', fontWeight: '900' },
  itemMeta: { color: '#59708f', marginTop: 4 },
  receiptRow: { borderBottomWidth: 1, borderBottomColor: '#edf2f7', paddingVertical: 12 },
  rawText: { color: '#314766', lineHeight: 21 },
  link: { color: '#2563eb', fontWeight: '900' },
});
