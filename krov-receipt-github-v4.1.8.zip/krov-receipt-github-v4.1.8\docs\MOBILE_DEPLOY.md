# Mobile Deploy

## 개발 테스트

```bash
cd mobile
npm install
npx expo start --go --tunnel --clear
```

휴대폰에서 Expo Go 앱으로 QR 코드를 스캔합니다.

## Android APK/AAB 빌드

EAS CLI를 설치합니다.

```bash
npm install -g eas-cli
cd mobile
eas login
eas build:configure
eas build -p android --profile preview
```

Play Store 배포용 AAB는 production profile을 사용합니다.

```bash
eas build -p android --profile production
```

## iPhone TestFlight/App Store

Apple Developer 계정이 필요합니다.

```bash
cd mobile
eas login
eas build:configure
eas build -p ios --profile production
```

빌드 후 App Store Connect 또는 EAS Submit으로 TestFlight에 올립니다.

```bash
eas submit -p ios
```

## API 설정

기본값은 `https://k-rov.com/api`입니다.

환경별로 바꾸려면 `mobile/.env`를 만듭니다.

```env
EXPO_PUBLIC_API_BASE_URL=https://k-rov.com/api
```

## 권한

앱은 카메라와 사진 접근 권한을 사용합니다.

- 카메라: 영수증 촬영
- 사진: 영수증 이미지 선택