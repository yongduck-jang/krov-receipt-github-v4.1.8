(() => {
  'use strict';

  const APP_BUILD = 'web-static-v4.1.8-ocr-502-fix';
  const API_BASE = `${window.location.origin}/api`;
  const state = {
    token: sessionStorage.getItem('krovToken') || '',
    user: safeJson(sessionStorage.getItem('krovUser')),
    receipts: [],
    currentImage: null,
    currentReceipt: null,
    currentRawText: '',
  };

  const $ = (id) => document.getElementById(id);
  const safe = (v) => (v ?? '').toString();
  const fmt = (n) => `${Number(n || 0).toLocaleString('ko-KR')}`;
  const won = (n) => `${fmt(n)}원`;
  const todayMonth = () => new Date().toISOString().slice(0, 7);
  const todayDate = () => new Date().toISOString().slice(0, 10);

  function safeJson(text) { try { return text ? JSON.parse(text) : null; } catch { return null; } }
  function toast(message, type = 'info') {
    const node = document.createElement('div');
    node.className = `toast ${type === 'error' ? 'error' : (type === 'ok' ? 'ok' : 'info')}`;
    node.textContent = message;
    document.body.appendChild(node);
    setTimeout(() => node.remove(), 4200);
  }
  function setLoading(message) { if ($('ocrStatus')) $('ocrStatus').textContent = message || ''; }
  function clearAuth(message = '') {
    state.token = '';
    state.user = null;
    state.receipts = [];
    sessionStorage.removeItem('krovToken');
    sessionStorage.removeItem('krovUser');
    if ($('logoutBtn')) $('logoutBtn').hidden = true;
    if (message && $('loginError')) $('loginError').textContent = message;
  }
  function ensureLoggedIn() {
    if (state.token) return true;
    clearAuth('로그인이 필요합니다. 다시 로그인하세요.');
    showPage('login');
    toast('로그인이 필요합니다.', 'error');
    return false;
  }

  async function api(path, options = {}) {
    const { timeoutMs: suppliedTimeoutMs, noAuthRedirect, ...fetchOptions } = options;
    const timeoutMs = suppliedTimeoutMs || (path.includes('/ocr/') ? 26000 : 18000);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    const headers = Object.assign({ 'Content-Type': 'application/json' }, fetchOptions.headers || {});
    if (state.token) {
      headers.Authorization = `Bearer ${state.token}`;
      headers['X-KROV-AUTHORIZATION'] = `Bearer ${state.token}`;
    }
    try {
      const response = await fetch(`${API_BASE}${path}`, { ...fetchOptions, headers, credentials: 'same-origin', signal: controller.signal });
      const contentType = response.headers.get('content-type') || '';
      const text = await response.text();
      if (/^\s*</.test(text) || /text\/html/i.test(contentType)) throw new Error(htmlResponseMessage(text, path, response.status));
      let data = null;
      try { data = text ? JSON.parse(text) : {}; } catch { data = { ok: false, message: text || `HTTP ${response.status}` }; }
      if (response.status === 401 && path !== '/auth/login.php') {
        if (!noAuthRedirect) {
          clearAuth(data.message || '토큰이 만료되었습니다. 다시 로그인하세요.');
          showPage('login');
        }
        throw new Error(data.message || '로그인이 필요합니다.');
      }
      if (!response.ok || data.ok === false) {
        const extra = data.diagnostic ? `\n${JSON.stringify(data.diagnostic, null, 2)}` : '';
        throw new Error((data.message || `HTTP ${response.status}`) + extra);
      }
      return data;
    } catch (error) {
      if (error.name === 'AbortError') throw new Error(`${path} 요청이 ${Math.round(timeoutMs / 1000)}초 안에 끝나지 않았습니다.`);
      throw error;
    } finally {
      clearTimeout(timer);
    }
  }
  function htmlResponseMessage(text, path, status) {
    const compact = String(text || '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
    return `API가 JSON이 아니라 HTML을 반환했습니다. (${path}, HTTP ${status})\n미리보기: ${compact.slice(0, 240)}`;
  }

  async function apiBlob(path) {
    const headers = state.token ? { Authorization: `Bearer ${state.token}`, 'X-KROV-AUTHORIZATION': `Bearer ${state.token}` } : {};
    const response = await fetch(`${API_BASE}${path}`, { headers, credentials: 'same-origin' });
    if (response.status === 401) {
      clearAuth('토큰이 만료되었습니다. 다시 로그인하세요.');
      showPage('login');
      throw new Error('로그인이 필요합니다.');
    }
    if (!response.ok) throw new Error(await response.text() || `HTTP ${response.status}`);
    return response.blob();
  }

  async function validateSession() {
    if (!state.token) return false;
    try {
      const data = await api('/auth/me.php', { method: 'GET', noAuthRedirect: true, timeoutMs: 12000 });
      state.user = data.user;
      sessionStorage.setItem('krovUser', JSON.stringify(state.user));
      return true;
    } catch (_) {
      clearAuth('기존 로그인 토큰이 유효하지 않습니다. 다시 로그인하세요.');
      return false;
    }
  }
  async function showApp() {
    if ($('boot')) $('boot').hidden = true;
    if ($('app')) $('app').hidden = false;
    const valid = await validateSession();
    if (valid) {
      $('logoutBtn').hidden = false;
      showPage('home');
      loadAll();
    } else {
      showPage('login');
    }
    updateDebugInfo();
    checkApiHealth();
  }
  function showPage(page) {
    $('app')?.classList.toggle('auth-mode', page === 'login');
    document.body.dataset.page = page;
    for (const node of document.querySelectorAll('.page')) { node.hidden = true; node.classList.remove('active'); }
    const target = $(`${page}Page`);
    if (target) { target.hidden = false; target.classList.add('active'); window.scrollTo({ top: 0, behavior: 'smooth' }); }
    for (const btn of document.querySelectorAll('.nav-btn')) btn.classList.toggle('active', btn.dataset.page === page);
    if (page === 'settings') renderSettings();
    if (page === 'reports') loadReport();
    if (page === 'receipts') renderReceiptTable();
  }
  async function checkApiHealth() {
    try {
      const res = await fetch(`${API_BASE}/health.php`, { cache: 'no-store' });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      $('apiStatus').textContent = 'API 정상';
      $('apiStatus').className = 'pill ok';
    } catch (_) {
      $('apiStatus').textContent = 'API 연결 실패';
      $('apiStatus').className = 'pill fail';
    }
  }
  async function login() {
    $('loginError').textContent = '';
    try {
      const data = await api('/auth/login.php', {
        method: 'POST',
        body: JSON.stringify({ email: $('loginEmail').value.trim(), password: $('loginPassword').value }),
      });
      if (!data.token) throw new Error('서버 로그인 응답에 token 값이 없습니다.');
      state.token = data.token;
      state.user = data.user;
      sessionStorage.setItem('krovToken', state.token);
      sessionStorage.setItem('krovUser', JSON.stringify(state.user));
      $('logoutBtn').hidden = false;
      toast('로그인 완료', 'ok');
      showPage('home');
      await loadAll();
      updateDebugInfo();
    } catch (error) {
      $('loginError').textContent = error.message;
    }
  }
  async function logout() {
    try {
      await fetch(`${API_BASE}/auth/logout.php`, {
        method: 'POST',
        headers: state.token ? { 'Content-Type': 'application/json', Authorization: `Bearer ${state.token}`, 'X-KROV-AUTHORIZATION': `Bearer ${state.token}` } : { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
      });
    } catch (_) {}
    clearAuth('로그아웃되었습니다.');
    showPage('login');
  }
  async function loadAll() {
    if (!state.token) return;
    await loadReceipts();
    if (state.token) await loadReport(false);
  }
  async function loadReceipts() {
    try {
      const data = await api('/receipts/list.php');
      state.receipts = data.receipts || [];
      renderHome();
      renderReceiptTable();
    } catch (error) {
      toast(`영수증 조회 실패: ${error.message}`, 'error');
    }
  }
  function renderHome() {
    const receipts = state.receipts;
    $('sumCount').textContent = fmt(receipts.length);
    $('sumPossible').textContent = fmt(receipts.reduce((s, r) => s + Number(r.expensePossibleAmount || 0), 0));
    $('sumPending').textContent = fmt(receipts.reduce((s, r) => s + Number(r.expensePendingAmount || 0), 0));
    $('sumRejected').textContent = fmt(receipts.reduce((s, r) => s + Number(r.expenseNotAllowedAmount || 0), 0));
    const recent = receipts.slice(0, 5);
    $('recentList').innerHTML = recent.length ? recent.map(renderListItem).join('') : '<p class="muted">등록된 영수증이 없습니다.</p>';
  }
  function renderListItem(r) {
    return `<div class="list-item"><div><strong>${escapeHtml(r.category || r.items?.[0]?.name || '영수증')}</strong><span>${escapeHtml(r.date || '')} · ${escapeHtml(r.storeName || r.sellerCompany || '')}</span></div><div class="align-right"><strong>${won(r.total)}</strong><span class="pill badge-${escapeAttr(r.expenseStatus || '확인필요')}">${escapeHtml(r.expenseStatus || '확인필요')}</span></div></div>`;
  }
  function filteredReceipts() {
    const q = $('searchInput')?.value.trim().toLowerCase() || '';
    const status = $('statusFilter')?.value || '';
    return state.receipts.filter((r) => {
      const hay = [r.category, r.storeName, r.sellerCompany, r.address, r.memo, r.rawText].map(safe).join(' ').toLowerCase();
      return (!q || hay.includes(q)) && (!status || r.expenseStatus === status);
    });
  }
  function renderReceiptTable() {
    const rows = filteredReceipts();
    $('receiptTableBody').innerHTML = rows.length ? rows.map((r) => {
      const workflow = r.workflowStatus || 'submitted';
      return `<tr><td>${escapeHtml(r.date || '')}<span class="small">${escapeHtml(r.time || '')}</span></td><td>${escapeHtml(r.category || '')}<span class="small">${escapeHtml(r.quantitySummary || '')}</span></td><td>${escapeHtml(r.storeName || r.sellerCompany || '')}<span class="small">${escapeHtml(r.address || '')}</span></td><td><strong>${won(r.total)}</strong></td><td>${won(r.vat)}</td><td><span class="pill badge-${escapeAttr(r.expenseStatus || '확인필요')}">${escapeHtml(r.expenseStatus || '확인필요')}</span></td><td><span class="pill badge-${escapeAttr(workflow)}">${translateWorkflow(workflow)}</span></td><td><div class="action-row"><button class="ghost" data-action="approve" data-id="${r.serverId}">승인</button><button class="ghost danger" data-action="reject" data-id="${r.serverId}">반려</button></div></td></tr>`;
    }).join('') : '<tr><td colspan="8" class="muted">데이터가 없습니다.</td></tr>';
  }
  function translateWorkflow(w) { return ({ draft: '작성중', submitted: '제출', approved: '승인', rejected: '반려' })[w] || w; }
  function handleReceiptAction(event) {
    const btn = event.target.closest('button[data-action]');
    if (!btn) return;
    const id = Number(btn.dataset.id);
    if (!id) return toast('서버 ID가 없습니다.', 'error');
    const action = btn.dataset.action;
    const path = action === 'approve' ? '/receipts/approve.php' : '/receipts/reject.php';
    api(path, { method: 'POST', body: JSON.stringify({ serverId: id, comment: action === 'approve' ? '웹앱 승인' : '웹앱 반려' }) })
      .then(() => { toast(action === 'approve' ? '승인 완료' : '반려 완료', 'ok'); return loadReceipts(); })
      .catch((e) => toast(`처리 실패: ${e.message}`, 'error'));
  }

  function updateSteps(step) { for (let i = 1; i <= 3; i++) $(`step${i}`)?.classList.toggle('active', i === step); }
  function readFileAsDataUrl(file) { return new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(String(reader.result || '')); reader.onerror = () => reject(reader.error || new Error('파일 읽기 실패')); reader.readAsDataURL(file); }); }
  function loadHtmlImage(dataUrl) { return new Promise((resolve, reject) => { const img = new Image(); img.onload = () => resolve(img); img.onerror = () => reject(new Error('이미지 형식을 읽지 못했습니다. JPG 또는 PNG로 다시 저장하세요.')); img.src = dataUrl; }); }
  async function compressImageForOcr(file) {
    const originalDataUrl = await readFileAsDataUrl(file);
    const originalBase64 = originalDataUrl.includes(',') ? originalDataUrl.split(',')[1] : originalDataUrl;
    const img = await loadHtmlImage(originalDataUrl);
    const maxDim = 960;
    const scale = Math.min(1, maxDim / Math.max(img.naturalWidth || img.width, img.naturalHeight || img.height));
    const width = Math.max(1, Math.round((img.naturalWidth || img.width) * scale));
    const height = Math.max(1, Math.round((img.naturalHeight || img.height) * scale));
    const canvas = document.createElement('canvas');
    canvas.width = width; canvas.height = height;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, width, height); ctx.drawImage(img, 0, 0, width, height);
    let quality = 0.68;
    let dataUrl = canvas.toDataURL('image/jpeg', quality);
    let base64 = dataUrl.split(',')[1] || '';
    while (base64.length > 850000 && quality > 0.38) {
      quality = Math.max(0.38, quality - 0.08);
      dataUrl = canvas.toDataURL('image/jpeg', quality);
      base64 = dataUrl.split(',')[1] || '';
    }
    return { name: file.name || 'receipt.jpg', mimeType: 'image/jpeg', format: 'jpg', dataUrl, base64, width, height, quality: Math.round(quality * 100) / 100, originalKb: Math.round(originalBase64.length / 1024), compressedKb: Math.round(base64.length / 1024) };
  }
  async function onFileChange() {
    const file = $('receiptFile').files?.[0];
    if (!file) return;
    try {
      $('ocrStatus').innerHTML = '<span class="file-meta">이미지 압축 중입니다. 잠시 기다리세요.</span>';
      const prepared = await compressImageForOcr(file);
      state.currentImage = prepared;
      $('imagePreview').src = prepared.dataUrl;
      $('imagePreview').hidden = false;
      $('imagePreviewWrap').classList.remove('empty');
      updateSteps(1);
      $('ocrStatus').innerHTML = `<div class="file-meta">${escapeHtml(file.name)} 선택됨<br>원본 약 ${fmt(prepared.originalKb)} KB → OCR 전송 ${fmt(prepared.compressedKb)} KB · ${prepared.width}×${prepared.height} · JPG 품질 ${prepared.quality}</div>`;
    } catch (error) {
      toast(`이미지 읽기/압축 실패: ${error.message}`, 'error');
      $('ocrStatus').textContent = '';
    }
  }
  async function runOcr() {
    if (!ensureLoggedIn()) return;
    if (!state.currentImage?.base64) return toast('영수증 이미지를 먼저 선택하세요.', 'error');
    try {
      updateSteps(2);
      setLoading(`OCR 분석 중입니다... 전송 크기 ${fmt(state.currentImage.compressedKb || Math.round(state.currentImage.base64.length / 1024))} KB`);
      const data = await api('/ocr/receipt.php', {
        method: 'POST',
        timeoutMs: 19000,
        body: JSON.stringify({ base64: state.currentImage.base64, format: state.currentImage.format || 'jpg', fileName: state.currentImage.name, mimeType: state.currentImage.mimeType || 'image/jpeg', clientBuild: APP_BUILD, imageMeta: { width: state.currentImage.width, height: state.currentImage.height, compressedKb: state.currentImage.compressedKb, originalKb: state.currentImage.originalKb } }),
      });
      state.currentRawText = data.rawText || '';
      $('rawText').textContent = state.currentRawText || 'OCR 텍스트가 비어 있습니다.';
      state.currentReceipt = parseReceipt(state.currentRawText);
      renderResultForm(state.currentReceipt);
      $('saveReceiptBtn').disabled = false;
      $('exportOneBtn').disabled = false;
      updateSteps(3);
      setLoading(`OCR 완료: ${data.provider || 'OCR'} / ${state.currentRawText.length.toLocaleString('ko-KR')}자`);
      toast('OCR 분석 완료', 'ok');
    } catch (error) {
      setLoading(`OCR 실패\n${error.message}`);
      toast(`OCR 실패: ${error.message}`, 'error');
      updateSteps(1);
    }
  }

  function parseReceipt(rawText) {
    const text = normalizeOcrText(rawText || '');
    const now = new Date();
    const dateMatch = text.match(/(20\d{2})[.\-\/년\s]+(\d{1,2})[.\-\/월\s]+(\d{1,2})/);
    const timeMatch = text.match(/(\d{1,2}:\d{2})(?::\d{2})?/);
    const date = dateMatch ? `${dateMatch[1]}-${pad(dateMatch[2])}-${pad(dateMatch[3])}` : todayDate();
    const time = timeMatch ? timeMatch[1] : `${pad(now.getHours())}:${pad(now.getMinutes())}`;
    const category = detectCategory(text);
    const status = classify(category);
    const seller = detectSeller(text, category);
    const address = detectAddress(text);
    let items = extractReceiptItems(text, category, status);
    const itemTotal = safeMoney(items.reduce((sum, item) => sum + safeMoney(item.amount), 0));
    let total = safeMoney(detectTotal(text, itemTotal) || itemTotal);
    if (itemTotal > 0 && total > itemTotal * 3 && total - itemTotal > 50000) total = itemTotal;
    const vat = safeMoney(detectVat(text, total));
    const supply = safeMoney(total - vat);
    if (!items.length && total > 0) items = [makeReceiptItem(category || '영수증', 1, null, total, category, status, 1)];
    items = distributeItemVat(items, total, vat, category, status);
    const payment = /현금|cash/i.test(text) ? '현금' : (/카드|신용|체크|삼성카드|BC|비씨/i.test(text) ? '신용카드' : '미확인');
    const possible = status === '가능' ? total : (status === '부분가능' ? Math.round(total * 0.35) : 0);
    const notAllowed = status === '불가' ? total : (status === '부분가능' ? Math.max(total - possible, 0) : 0);
    const pending = status === '확인필요' ? total : 0;
    return { id: `web-${Date.now()}`, date, time, user: state.user?.name || '', category, items, amount: total, supplyAmount: supply, vat, total, taxFreeAmount: detectTaxFreeAmount(text), paymentMethod: payment, cardCompany: detectCard(text), cardMasked: detectCardMasked(text), quantitySummary: items.length ? `${items.length}개 품목` : detectQuantity(text), sellerCompany: seller, storeName: seller, address, businessNo: detectBusinessNo(text), phone: detectPhone(text), expenseStatus: status, expensePossibleAmount: possible, expensePendingAmount: pending, expenseNotAllowedAmount: notAllowed, workflowStatus: 'submitted', memo: reasonFor(category, status), rawText: text, sourceImageUri: '' };
  }

  function normalizeOcrText(text) { return String(text || '').replace(/\u00a0/g, ' ').replace(/[，]/g, ',').replace(/[₩￦]/g, '원').replace(/[‐‑‒–—―]/g, '-'); }
  function receiptLines(text) { return normalizeOcrText(text).split(/\r?\n/).map((line) => line.replace(/\s+/g, ' ').trim()).filter(Boolean); }
  function pad(v) { return String(v).padStart(2, '0'); }
  function safeMoney(value) { const n = Number(value); return Number.isFinite(n) && n > 0 ? Math.round(n) : 0; }
  function safeQuantity(value) { const n = Number(value); return Number.isFinite(n) && n > 0 ? Math.round(n * 1000) / 1000 : 1; }
  function toMoney(value) { const digits = String(value || '').replace(/[^0-9]/g, ''); if (!digits) return 0; const n = Number(digits); return Number.isFinite(n) ? n : 0; }
  function detectCategory(text) {
    if (/휘발유|경유|주유|셀프주유소|주유소|유종|리터|\bLPG\b/i.test(text)) return '주유비';
    if (/통행료|하이패스|도로공사|톨게이트/i.test(text)) return '통행료';
    if (/주차|parking|공영주차/i.test(text)) return '주차요금';
    if (/식대|회식|식당|카페|커피|스타벅스|맥도날드|음식|분식|고기|치킨/i.test(text)) return '식대';
    if (/약국|의약품|구급|파스|연고|밴드|거즈|소독|멸균|드레싱|포비돈|타이레놀|판피린|비겐|크림|멘소래담|생력/i.test(text)) return '약국/구급품';
    if (/문구|사무|복사용지|토너|잉크|파일|테이프/i.test(text)) return '사무용품';
    return '기타';
  }
  function classify(category) { if (['주유비', '통행료', '주차요금', '사무용품'].includes(category)) return '가능'; if (category === '약국/구급품') return '부분가능'; return '확인필요'; }
  function reasonFor(category, status) { if (status === '가능') return `${category} 항목은 업무 관련성 확인 시 비용 처리 가능`; if (status === '부분가능') return '현장 구급/비상용 품목은 가능, 개인 복용/개인용품은 제외 검토 필요'; if (status === '불가') return '업무 관련성 낮음'; return '거래처, 참석자, 업무 목적 확인 필요'; }
  function isIdentifierLine(line) { return /승인\s*번호|카드\s*번호|유효\s*기간|사업자|전화|TEL|영수증\s*NO|영수증번호|가맹점|매입사|카드명|주소|일자|날짜|포스|POS|TID|NOZZLE|거래번호|주유기번호/i.test(line); }
  function extractMoneyValues(line, loose = false) {
    const source = String(line || '');
    const values = [];
    const commaAmountPattern = /\d{1,3}(?:,\d{3})+(?:\s*원)?/g;
    for (const match of source.match(commaAmountPattern) || []) values.push(toMoney(match));
    const bareSource = source.replace(commaAmountPattern, ' ');
    if (loose || /원|금액|합계|총액|결제|청구|받는|받은|카드|소계|VAT|부가세|공급가액|판매금액|amount|total/i.test(source)) {
      for (const match of bareSource.match(/\b\d{3,9}\b/g) || []) values.push(toMoney(match));
    }
    return [...new Set(values)].filter((n) => n > 0 && n < 1000000000);
  }
  function moneyNearLine(lines, i, loose = true) { const parts = [lines[i]]; for (let j = i + 1; j < Math.min(lines.length, i + 5); j++) { if (isIdentifierLine(lines[j])) break; parts.push(lines[j]); if (extractMoneyValues(parts.join(' '), loose).length) break; } return extractMoneyValues(parts.join(' '), loose); }
  function pickTotalCandidate(values, hintTotal = 0) { const filtered = values.filter((n) => n > 0 && n < 1000000000); if (!filtered.length) return 0; const last = filtered[filtered.length - 1]; if (hintTotal > 0 && last > hintTotal * 3 && last - hintTotal > 50000) return hintTotal; return last; }
  function detectTotal(text, hintTotal = 0) {
    const lines = receiptLines(text);
    const totalKeywords = /청구\s*금액|받는\s*금액|받은\s*금액|결제\s*금액|합\s*계|총\s*액|총\s*금액|신용\s*카드|카드\s*결제|소\s*계|판매\s*금액|total|amount/i;
    const notTotal = /부가세|부\s*가\s*세|공급\s*가|면세|과세\s*물품/i;
    for (let i = lines.length - 1; i >= 0; i--) {
      const line = lines[i];
      if (!totalKeywords.test(line) || notTotal.test(line) || isIdentifierLine(line)) continue;
      const candidate = pickTotalCandidate(moneyNearLine(lines, i, true), hintTotal);
      if (candidate) return candidate;
    }
    if (hintTotal > 0) return hintTotal;
    const fallback = [];
    for (const line of lines) { if (!isIdentifierLine(line) && !notTotal.test(line)) fallback.push(...extractMoneyValues(line, false)); }
    return fallback.length ? Math.max(...fallback) : 0;
  }
  function detectVat(text, total) { const lines = receiptLines(text); for (let i = 0; i < lines.length; i++) { if (!/(^|\s)(VAT|부\s*가\s*세|부가세|세액)(\s|:|：|$)/i.test(lines[i])) continue; const values = extractMoneyValues(lines.slice(i, i + 10).join(' '), true).filter((n) => n > 0 && (!total || n <= Math.round(total * 0.2))); if (values.length) return values[values.length - 1]; } return total ? Math.round(total / 11) : 0; }
  function detectTaxFreeAmount(text) { const lines = receiptLines(text); const idx = lines.findIndex((l) => /면세\s*물품|면세\s*금액|비과세/i.test(l)); if (idx < 0) return 0; const values = extractMoneyValues(lines.slice(idx, idx + 8).join(' '), true); return values.length ? values[values.length - 1] : 0; }

  function extractReceiptItems(text, defaultCategory, defaultStatus) {
    const lines = receiptLines(text);
    const pharmacyItems = extractPharmacyColumnItems(lines, defaultCategory, defaultStatus, text);
    if (pharmacyItems.length >= 3) return pharmacyItems;
    let start = lines.findIndex((line) => /품명|품목|상품명|제품명|내역|단가.*수량.*금액/i.test(line));
    if (start < 0) start = -1;
    const section = [];
    for (let i = start + 1; i < lines.length; i++) {
      const line = lines[i].replace(/^[-=*\s]+|[-=*\s]+$/g, '').trim();
      if (!line || isItemHeaderLine(line)) continue;
      if (isItemFooterLine(line)) break;
      section.push(line);
    }
    const items = [];
    for (let i = 0; i < section.length; i++) {
      const line = section[i];
      const inline = parseInlineItem(line, defaultCategory, defaultStatus, items.length + 1);
      if (inline) { items.push(inline); continue; }
      if (!looksLikeItemName(line)) continue;
      const nameParts = [line];
      let cursor = i + 1;
      while (cursor < section.length && isItemNameContinuation(section[cursor]) && numericRunLength(section, cursor + 1) > 0) { nameParts.push(section[cursor]); cursor++; }
      const tokens = [];
      while (cursor < section.length && isNumericOnlyLine(section[cursor]) && tokens.length < 6) { tokens.push(...numericTokens(section[cursor])); cursor++; }
      const item = makeItemFromTokens(nameParts.join(' '), tokens, defaultCategory, defaultStatus, items.length + 1);
      if (item) { items.push(item); i = cursor - 1; }
    }
    return items.filter((item) => item.amount > 0);
  }
  function extractPharmacyColumnItems(lines, defaultCategory, defaultStatus, fullText) {
    if (defaultCategory !== '약국/구급품' && !/약국|파스|연고|밴드|거즈|타이레놀|판피린/i.test(fullText || '')) return [];
    const start = lines.findIndex((line) => /품명|제품명|상품명|단가|수량|금액/i.test(line));
    const end = lines.findIndex((line, idx) => idx > start && /소\s*계|청구\s*금액|받은\s*금액|신용\s*카드|카드\s*번호|결제\s*금액/i.test(line));
    if (start < 0 || end <= start) return [];
    const section = lines.slice(start + 1, end).map((line) => line.replace(/^[-=*\s]+|[-=*\s]+$/g, '').trim()).filter(Boolean);
    const names = orderPharmacyNames(collectPharmacyNames(section));
    const total = safeMoney(detectTotal(fullText, 0));
    const amounts = findAmountRun(extractColumnAmounts(section, total), total, names.length);
    if (names.length < 3 || amounts.length < 3) return [];
    return names.slice(0, Math.min(names.length, amounts.length)).map((name, idx) => {
      const amount = safeMoney(amounts[idx]);
      const detail = pharmacyQuantityAndUnitPrice(name, amount);
      return makeReceiptItem(name, detail.quantity, detail.unitPrice, amount, defaultCategory, defaultStatus, idx + 1);
    });
  }
  function collectPharmacyNames(section) { const names = []; let current = ''; for (const rawLine of section) { const line = rawLine.replace(/\s+/g, ' ').trim(); if (!line || isNumericOnlyLine(line) || isItemHeaderLine(line) || isItemFooterLine(line)) continue; if (/^[,:：]+$/.test(line) || /^(단가|수량|금액|품명|제품명)$/i.test(line)) continue; if (isPharmacyContinuation(line)) { if (current) current = `${current} ${line}`.trim(); continue; } if (!/[가-힣A-Za-z]/.test(line)) continue; if (current) names.push(current); current = line; } if (current) names.push(current); return names.map((name) => name.replace(/\s+/g, ' ').trim()).filter(Boolean); }
  function isPharmacyContinuation(line) { return /^\(?[^)]*변방\)?$/i.test(line) || /^(혼합|대체변방)$/i.test(line) || /^\d+(?:\.\d+)?\s*(?:P|T|g|mg|ml|mL|L|병|매|개입|ea|EA|포|정|봉|팩)$/i.test(line); }
  function extractColumnAmounts(section, total) { const values = []; for (const line of section) { if (!(isNumericOnlyLine(line) || /\d{1,3}(?:,\d{3})+/.test(line))) continue; for (const n of numericTokens(line)) { if (n > 100 && (!total || n < total)) values.push(safeMoney(n)); } } return values; }
  function findAmountRun(values, total, targetCount) { if (!values.length) return []; if (!total) return values.slice(-targetCount); for (let start = 0; start < values.length; start++) { let sum = 0; const run = []; for (let end = start; end < values.length; end++) { sum += values[end]; run.push(values[end]); if (sum === total && run.length >= Math.min(3, targetCount || run.length)) return run; if (sum > total) break; } } return values.slice(-targetCount); }
  function orderPharmacyNames(names) { const preferred = ['자하생력', '판피린큐맥', '판피린큐액', '제일롱파프', '리스테린', '멸균거즈', '경방갈근', '용표우황', '비겐크림', '타이레놀', '가그린', '후시딘', '밴드닥터', '포비돈', '로푸록스']; const ordered = []; const used = new Set(); for (const key of preferred) { const idx = names.findIndex((name, i) => !used.has(i) && name.includes(key)); if (idx >= 0) { ordered.push(names[idx]); used.add(idx); } } for (let i = 0; i < names.length; i++) if (!used.has(i)) ordered.push(names[i]); return ordered; }
  function pharmacyQuantityAndUnitPrice(name, amount) { if (/판피린큐액/i.test(name) && amount === 27500) return { quantity: 11, unitPrice: 2500 }; if (/용표우황/i.test(name) && amount === 20000) return { quantity: 4, unitPrice: 5000 }; return { quantity: 1, unitPrice: amount }; }
  function isItemHeaderLine(line) { return /^(품명|품목|상품명|제품명|내역|단가|수량|금액)$|품명\s+단가|단가\s+수량/i.test(line); }
  function isItemFooterLine(line) { return /소\s*계|합\s*계|청구\s*금액|받는\s*금액|받은\s*금액|거스름돈|부가세|공급\s*가액|신용\s*카드|카드\s*번호|유효\s*기간|가맹점|매입사|결제\s*금액|승인\s*번호|면세\s*물품|과세\s*물품/i.test(line); }
  function isNumericOnlyLine(line) { return /^[\d,.\s원]+$/.test(String(line || '').trim()); }
  function numericTokens(line) { return (String(line || '').match(/\d{1,3}(?:,\d{3})+|\b\d+(?:\.\d+)?\b/g) || []).map((value) => Number(String(value).replace(/,/g, ''))).filter((n) => Number.isFinite(n) && n >= 0); }
  function numericRunLength(lines, start) { let count = 0; for (let i = start; i < lines.length && isNumericOnlyLine(lines[i]); i++) count++; return count; }
  function looksLikeItemName(line) { const s = String(line || '').trim(); if (!s || isIdentifierLine(s) || isItemFooterLine(s) || isItemHeaderLine(s) || isNumericOnlyLine(s)) return false; if (/^(주소|전화|성명|일자|포스|사업자|대표|카드|가맹점|매입사)\s*[:：]?/i.test(s)) return false; return /[가-힣A-Za-z]/.test(s); }
  function isItemNameContinuation(line) { return /^[\d.\s]+(?:병|개|매|ml|mL|g|kg|L|P|포|입|ea|EA|T|정|봉|팩)\b/i.test(line); }
  function parseInlineItem(line, defaultCategory, defaultStatus, index) { const s = String(line || '').replace(/\s+/g, ' ').trim(); if (!looksLikeItemName(s)) return null; let m = s.match(/^(.+?)\s+(\d{1,3}(?:,\d{3})+|\d{3,9})\s+(\d+(?:\.\d+)?)\s+(\d{1,3}(?:,\d{3})+|\d{3,9})(?:\s*원)?$/); if (m) return makeReceiptItem(m[1], Number(m[3]) || 1, toMoney(m[2]), toMoney(m[4]), defaultCategory, defaultStatus, index); m = s.match(/^(.+?)\s+(\d{1,3}(?:,\d{3})+)(?:\s*원)?$/); if (m) return makeReceiptItem(m[1], 1, null, toMoney(m[2]), defaultCategory, defaultStatus, index); return null; }
  function makeItemFromTokens(name, tokens, defaultCategory, defaultStatus, index) { const values = tokens.filter((n) => Number.isFinite(n) && n > 0); if (!values.length) return null; let quantity = 1; let unitPrice = null; let amount = safeMoney(values[values.length - 1]); if (values.length >= 3) { const first = values[0]; const second = values[1]; if (first > 0 && first < 1000 && second >= 100 && Math.abs((first * second) - amount) <= Math.max(100, amount * 0.08)) { quantity = first; unitPrice = second; } else if (second > 0 && second < 1000 && first >= 100) { unitPrice = first; quantity = second; } else { unitPrice = first >= 100 ? first : null; quantity = unitPrice ? safeQuantity(amount / unitPrice) : 1; } } else if (values.length === 2) { unitPrice = values[0] >= 100 ? values[0] : null; amount = safeMoney(values[1]); } return makeReceiptItem(name, quantity, unitPrice, amount, defaultCategory, defaultStatus, index); }
  function makeReceiptItem(name, quantity, unitPrice, amount, defaultCategory, defaultStatus, index) { const cleanName = String(name || '미분류 품목').replace(/^\*+/, '').replace(/\s+/g, ' ').trim() || '미분류 품목'; const detected = detectCategory(cleanName); const category = detected === '기타' ? defaultCategory : detected; const status = defaultStatus || classify(category); return { id: `item-${index}`, name: cleanName.slice(0, 180), category, quantity: safeQuantity(quantity), unit: '', unitPrice: safeMoney(unitPrice) || null, amount: safeMoney(amount), vat: 0, expenseStatus: status, reason: reasonFor(category, status) }; }
  function distributeItemVat(items, total, vat, defaultCategory, defaultStatus) { if (!items.length) return items; let assignedVat = 0; return items.map((item, idx) => { const category = item.category || defaultCategory; const status = item.expenseStatus || defaultStatus; const itemAmount = safeMoney(item.amount); const itemVat = idx === items.length - 1 ? safeMoney(vat - assignedVat) : (total && vat ? safeMoney(vat * itemAmount / total) : safeMoney(itemAmount / 11)); assignedVat += itemVat; return { ...item, id: item.id || `item-${idx + 1}`, category, expenseStatus: status, vat: itemVat, reason: item.reason || reasonFor(category, status) }; }); }

  function detectSeller(text, category) { const lines = receiptLines(text).slice(0, 16); const blocked = /영수증|사업자|주소|전화|성명|일자|포스|카드|가맹점|매입사|승인|NO\s*[:：]?|대표|TID|NOZZLE/i; const likely = lines.find((line) => !blocked.test(line) && /(약국|주유소|식당|카페|마트|상사|병원|문구|커피|공영|도로공사|하이패스|parking|store|pharmacy|에너지)/i.test(line)); const first = likely || lines.find((line) => !blocked.test(line) && /[가-힣A-Za-z]/.test(line)); return cleanupSeller(first || category); }
  function cleanupSeller(value) { return String(value || '').replace(/^(서울|부산|대구|인천|광주|대전|울산|세종|경기|강원|충북|충남|전북|전남|경북|경남|제주)\s+/, '').replace(/\s+/g, ' ').trim(); }
  function detectAddress(text) { const line = receiptLines(text).find((l) => /(서울|부산|대구|인천|광주|대전|울산|세종|경기|강원|충북|충남|전북|전남|경북|경남|제주).*(시|군|구).*(로|길|대로)\s*\d*/.test(l)); return line ? line.replace(/^주소\s*[:：]?\s*/, '').trim() : ''; }
  function detectBusinessNo(text) { const lines = receiptLines(text); const idx = lines.findIndex((line) => /사업자\s*번호/i.test(line)); const source = idx >= 0 ? [lines[idx], lines[idx + 1] || '', lines[idx + 2] || ''].join(' ') : text; const m = source.match(/(\d{3})-?(\d{2})-?(\d{5})/); return m ? `${m[1]}-${m[2]}-${m[3]}` : ''; }
  function detectPhone(text) { return text.match(/0\d{1,2}-\d{3,4}-\d{4}/)?.[0] || ''; }
  function detectCard(text) { const brandPattern = /(삼성|현대|국민|신한|우리|롯데|하나|농협|BC|비씨)[\s-]*(카드|카드사)?/i; const lines = receiptLines(text); for (let i = lines.length - 1; i >= 0; i--) { const windowText = [lines[i - 1] || '', lines[i], lines[i + 1] || ''].join(' '); if (!/카드|매입|승인|사\s*[:：]?/i.test(windowText)) continue; const m = windowText.match(brandPattern); if (m) return `${m[1]}카드`.replace(/^BC카드$/i, 'BC카드').replace(/^비씨카드$/, '비씨카드'); } return ''; }
  function detectCardMasked(text) { return text.match(/\d{4}[-\s]\d{4}[-\s][*Xx]{2,4}[-\s][*Xx]{2,4}/)?.[0] || ''; }
  function detectQuantity(text) { const m = text.match(/\d+(?:\.\d+)?\s*(?:L|리터|개|건|시간|분|매|병|포)/i); return m ? m[0] : '1건'; }

  function itemsToText(items = []) { return items.length ? items.map((item) => [item.name || '', item.quantity || 1, item.unitPrice || '', item.amount || 0].join(' | ')).join('\n') : ''; }
  function itemsFromText(text, defaultCategory, defaultStatus, reason) { return String(text || '').split(/\r?\n/).map((line) => line.trim()).filter(Boolean).map((line, idx) => { if (/^품명\s*\|/i.test(line)) return null; const parts = line.split(/\s*\|\s*|\t+/).filter((part) => part !== ''); if (parts.length >= 4) return makeReceiptItem(parts[0], Number(parts[1]) || 1, toMoney(parts[2]), toMoney(parts[3]), defaultCategory, defaultStatus, idx + 1); return parseInlineItem(line, defaultCategory, defaultStatus, idx + 1); }).filter(Boolean).map((item) => ({ ...item, reason: item.reason || reason || reasonFor(item.category, item.expenseStatus) })); }
  function renderResultForm(r) {
    const view = { ...r, itemsText: itemsToText(r.items || []) };
    const fields = [['date', '날짜'], ['time', '시간'], ['category', '사용 품목'], ['user', '사용자'], ['sellerCompany', '판매 회사'], ['storeName', '판매처'], ['address', '주소', 'wide'], ['amount', '금액'], ['supplyAmount', '공급가액'], ['vat', 'VAT'], ['total', 'Total'], ['paymentMethod', '결제 방법'], ['quantitySummary', '수량/품목수'], ['expenseStatus', '비용처리 상태'], ['memo', '메모', 'wide'], ['itemsText', '품목 정리', 'wide']];
    $('resultForm').innerHTML = fields.map(([key, label, wide]) => {
      if (key === 'itemsText') return `<div class="${wide || ''}"><label>${label}</label><textarea data-field="${key}" rows="7">${escapeHtml(view[key] ?? '')}</textarea><small class="muted">품명 | 수량 | 단가 | 금액 형식으로 저장됩니다.</small></div>`;
      return `<div class="${wide || ''}"><label>${label}</label><input data-field="${key}" value="${escapeAttr(view[key] ?? '')}" /></div>`;
    }).join('');
  }
  function collectReceiptForm() {
    const r = { ...state.currentReceipt };
    for (const input of document.querySelectorAll('#resultForm [data-field]')) {
      const key = input.dataset.field;
      let value = input.value;
      if (['amount', 'supplyAmount', 'vat', 'total'].includes(key)) value = Number(value.replace(/[^0-9]/g, '')) || 0;
      r[key] = value;
    }
    const parsedItems = itemsFromText(r.itemsText, r.category || '기타', r.expenseStatus || '확인필요', r.memo || '');
    r.items = distributeItemVat(parsedItems.length ? parsedItems : (r.items || []), r.total || r.amount || 0, r.vat || 0, r.category || '기타', r.expenseStatus || '확인필요');
    if (!r.items.length) r.items = [makeReceiptItem(r.category || '영수증', 1, null, r.total || 0, r.category || '기타', r.expenseStatus || '확인필요', 1)];
    r.quantitySummary = r.items.length ? `${r.items.length}개 품목` : (r.quantitySummary || '1건');
    if (r.expenseStatus === '가능') { r.expensePossibleAmount = r.total; r.expensePendingAmount = 0; r.expenseNotAllowedAmount = 0; }
    else if (r.expenseStatus === '불가') { r.expensePossibleAmount = 0; r.expensePendingAmount = 0; r.expenseNotAllowedAmount = r.total; }
    else if (r.expenseStatus === '부분가능') { r.expensePossibleAmount = Number(r.expensePossibleAmount || Math.round(r.total * .35)); r.expensePendingAmount = 0; r.expenseNotAllowedAmount = Math.max(r.total - r.expensePossibleAmount, 0); }
    else { r.expensePossibleAmount = 0; r.expensePendingAmount = r.total; r.expenseNotAllowedAmount = 0; }
    delete r.itemsText;
    return r;
  }
  async function saveReceipt() { if (!ensureLoggedIn()) return; try { const receipt = collectReceiptForm(); const data = await api('/receipts/create.php', { method: 'POST', body: JSON.stringify(receipt) }); state.currentReceipt = data.receipt; toast('영수증 저장 완료', 'ok'); await loadReceipts(); showPage('receipts'); } catch (error) { toast(`저장 실패: ${error.message}`, 'error'); } }
  async function loadReport(showToast = true) { if (!state.token) return; const month = $('reportMonth').value || todayMonth(); try { const data = await api(`/reports/monthly.php?month=${encodeURIComponent(month)}`); renderReport(data); if (showToast) toast('리포트 조회 완료', 'ok'); } catch (error) { if (showToast) toast(`리포트 조회 실패: ${error.message}`, 'error'); } }
  function renderReport(data) { const s = data.summary || {}; $('reportSummary').innerHTML = [['월계 건수', fmt(s.count), '건', 'blue'], ['Total', fmt(s.total), '원', 'green'], ['VAT', fmt(s.vat), '원', 'orange'], ['불가 금액', fmt(s.notAllowed), '원', 'red']].map(([label, value, unit, cls]) => `<div class="summary-card ${cls}"><span>${label}</span><strong>${value}</strong><em>${unit}</em></div>`).join(''); $('reportTableBody').innerHTML = (data.rows || []).length ? data.rows.map((r) => `<tr><td>${escapeHtml(r.category)}</td><td>${escapeHtml(r.expense_status)}</td><td>${translateWorkflow(r.workflow_status)}</td><td>${fmt(r.count)}</td><td>${won(r.total)}</td><td>${won(r.vat)}</td></tr>`).join('') : '<tr><td colspan="6" class="muted">집계 데이터가 없습니다.</td></tr>'; }
  function excelSafe(value) { const s = safe(value); return /^[=+\-@\t\r\n]/.test(s) ? `'${s}` : s; }
  async function downloadMonthlyExcel() { try { const month = $('reportMonth').value || todayMonth(); const blob = await apiBlob(`/export/monthly_excel.php?month=${encodeURIComponent(month)}`); downloadBlob(blob, `krov-monthly-report-${month}.xls`); } catch (error) { toast(`월별 Excel 다운로드 실패: ${error.message}`, 'error'); } }
  function exportReceiptsExcel(rows = filteredReceipts(), filename = `krov-receipts-${todayDate()}.xls`) { const headers = ['날짜','시간','사용 품목','사용자','주소','금액','공급가액','VAT','결제 방법','수량','Total','회사 비용 처리 가능','확인필요','비용 처리 불가','판매 회사','판매처','승인상태','메모']; const htmlRows = rows.map((r) => [r.date,r.time,r.category,r.user,r.address,r.amount,r.supplyAmount,r.vat,r.paymentMethod,r.quantitySummary,r.total,r.expensePossibleAmount,r.expensePendingAmount,r.expenseNotAllowedAmount,r.sellerCompany,r.storeName,translateWorkflow(r.workflowStatus),r.memo].map((v) => `<td>${escapeHtml(excelSafe(v))}</td>`).join('')); const html = `<!doctype html><html><head><meta charset="utf-8"></head><body><table border="1"><thead><tr>${headers.map((h)=>`<th>${h}</th>`).join('')}</tr></thead><tbody>${htmlRows.map((r)=>`<tr>${r}</tr>`).join('')}</tbody></table></body></html>`; downloadBlob(new Blob(['\ufeff', html], { type: 'application/vnd.ms-excel;charset=utf-8' }), filename); }
  function downloadBlob(blob, filename) { const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000); }
  function resetRegister() { state.currentImage = null; state.currentReceipt = null; state.currentRawText = ''; $('receiptFile').value = ''; $('imagePreview').src = ''; $('imagePreview').hidden = true; $('imagePreviewWrap').classList.add('empty'); $('resultForm').innerHTML = ''; $('rawText').textContent = '아직 분석된 원문이 없습니다.'; $('saveReceiptBtn').disabled = true; $('exportOneBtn').disabled = true; $('ocrStatus').textContent = ''; updateSteps(1); }
  async function changePassword() { try { await api('/auth/change_password.php', { method: 'POST', body: JSON.stringify({ currentPassword: $('currentPassword').value, newPassword: $('newPassword').value }) }); $('passwordStatus').textContent = '비밀번호 변경 완료'; $('currentPassword').value = ''; $('newPassword').value = ''; toast('비밀번호 변경 완료', 'ok'); } catch (error) { $('passwordStatus').textContent = error.message; toast(`비밀번호 변경 실패: ${error.message}`, 'error'); } }
  function renderSettings() { const u = state.user || {}; $('userInfo').innerHTML = [['회사', u.company_name || u.companyName || ''], ['이름', u.name || ''], ['이메일', u.email || ''], ['권한', u.role || ''], ['API', API_BASE], ['Build', APP_BUILD]].map(([k, v]) => `<dt>${k}</dt><dd>${escapeHtml(v)}</dd>`).join(''); updateDebugInfo(); }
  function updateDebugInfo() { const debug = { href: window.location.href, apiBase: API_BASE, hasToken: Boolean(state.token), user: state.user ? { email: state.user.email, role: state.user.role, company: state.user.company_name } : null, userAgent: navigator.userAgent, build: APP_BUILD }; const node = $('debugInfo'); if (node) node.textContent = JSON.stringify(debug, null, 2); }
  function escapeHtml(value) { return safe(value).replace(/[&<>'"]/g, (c) => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', "'":'&#39;', '"':'&quot;' }[c])); }
  function escapeAttr(value) { return escapeHtml(value); }

  function bind() {
    for (const btn of document.querySelectorAll('[data-page]')) btn.addEventListener('click', () => showPage(btn.dataset.page));
    for (const btn of document.querySelectorAll('[data-page-link]')) btn.addEventListener('click', () => showPage(btn.dataset.pageLink));
    $('loginBtn')?.addEventListener('click', login);
    $('loginPassword')?.addEventListener('keydown', (e) => { if (e.key === 'Enter') login(); });
    $('logoutBtn')?.addEventListener('click', logout);
    $('receiptFile')?.addEventListener('change', onFileChange);
    $('ocrBtn')?.addEventListener('click', runOcr);
    $('resetRegisterBtn')?.addEventListener('click', resetRegister);
    $('saveReceiptBtn')?.addEventListener('click', saveReceipt);
    $('exportOneBtn')?.addEventListener('click', () => exportReceiptsExcel([collectReceiptForm()], `krov-receipt-${todayDate()}.xls`));
    $('copyRawBtn')?.addEventListener('click', () => navigator.clipboard?.writeText(state.currentRawText || '').then(() => toast('OCR 원문 복사 완료', 'ok')));
    $('refreshBtn')?.addEventListener('click', loadReceipts);
    $('exportListBtn')?.addEventListener('click', () => exportReceiptsExcel());
    $('receiptTableBody')?.addEventListener('click', handleReceiptAction);
    $('searchInput')?.addEventListener('input', renderReceiptTable);
    $('statusFilter')?.addEventListener('change', renderReceiptTable);
    if ($('reportMonth')) $('reportMonth').value = todayMonth();
    $('loadReportBtn')?.addEventListener('click', () => loadReport(true));
    $('downloadMonthlyBtn')?.addEventListener('click', downloadMonthlyExcel);
    $('changePasswordBtn')?.addEventListener('click', changePassword);
  }
  window.addEventListener('error', (event) => { toast(`웹앱 오류: ${event.message}`, 'error'); const boot = $('boot'); if (boot && !$('app')?.hidden) return; if (boot) boot.querySelector('p').textContent = `오류: ${event.message}`; });
  window.addEventListener('unhandledrejection', (event) => { toast(`비동기 오류: ${event.reason?.message || event.reason}`, 'error'); });
  bind();
  showApp();
})();
