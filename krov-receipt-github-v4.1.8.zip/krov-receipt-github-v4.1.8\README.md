# K-ROV Receipt Expense v4.1.8

K-ROV 영수증 비용관리 웹앱과 모바일 앱 배포용 저장소입니다.

## 구조

```text
web/      Cafe24 /www/app 에 업로드하는 웹앱 파일
mobile/   Expo React Native 모바일 앱 프로젝트
docs/     배포 안내 문서
```

## Web 배포

`web` 폴더의 파일 3개를 Cafe24에 업로드합니다.

```text
web/index.html -> /www/app/index.html
web/app.js     -> /www/app/app.js
web/.htaccess  -> /www/app/.htaccess
```

배포 후 접속:

```text
https://k-rov.com/app/?v=4.1.8
```

## Mobile 실행

```bash
cd mobile
npm install
npx expo start --go --tunnel --clear
```

기본 API 주소:

```text
https://k-rov.com/api
```

다른 API를 쓰려면 `mobile/.env` 파일을 만들고 설정합니다.

```env
EXPO_PUBLIC_API_BASE_URL=https://k-rov.com/api
```

## Mobile 실제 배포

Android는 APK/AAB, iPhone은 TestFlight/App Store 배포를 사용합니다. 자세한 절차는 `docs/MOBILE_DEPLOY.md`를 참고하세요.

## 주의

- 서버 비밀번호, NAVER OCR Secret, DB 정보는 GitHub에 올리지 마세요.
- `/www/api/_config.php` 같은 운영 설정 파일은 저장소에 포함하지 않습니다.
- `.htaccess`는 숨김 파일이라 FTP/Git 클라이언트에서 숨김 파일 표시가 필요할 수 있습니다.