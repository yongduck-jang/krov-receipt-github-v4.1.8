# K-ROV Mobile App

Expo React Native 기반 모바일 앱입니다.

## 실행

```bash
npm install
npx expo start --go --tunnel --clear
```

## 기능

- 로그인
- 카메라 촬영 / 앨범 선택
- 이미지 압축 후 OCR 전송
- 주유/약국 영수증 정리
- 영수증 저장
- 최근 영수증 목록 조회